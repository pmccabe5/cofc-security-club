#!/bin/bash

#simple password generator

echo "Enter the length of the password: "
read LENGTH 

for P in $(seq 1); 
do
	openssl rand -base64 48 | cut  -c1-$LENGTH
done
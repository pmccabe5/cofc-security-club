#!/bin/bash

#menus

echo "Welcome to Bob's Burgers"
echo "Please choose what you want to eat: "
meals="Burger Fries"

select option in $meals; do
	echo "The selected option is $REPLY"
	echo "The selected meal is $option"
done

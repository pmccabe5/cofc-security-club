#!/bin/bash

#test scripts
if [ -d /usr/share/wordlists ];
then
	echo "yes it exists"
else
	echo "nope"
fi
# !/bin/bash

#Read user data

echo "Please enter your full name: "
read FIRSTNAME LASTNAME	
echo "Your name is $FIRSTNAME $LASTNAME"


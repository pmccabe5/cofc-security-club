#!/bin/bash

#functions

function shadowtest(){

	if [ -e /etc/shadow ];
	then
		echo "yes it exists"
	else
		echo "Nope"
	fi

}

function testpwd(){

	if [ -e /etc/passwd ];
	then
		echo "yes it exists"
	else
		echo "Nope"
	fi
}

shadowtest
testpwd
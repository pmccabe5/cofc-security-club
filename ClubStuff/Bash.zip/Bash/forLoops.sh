#!/bin/bash

#for loops

for NAMES in $(cat names.txt); do
	echo "The name is $NAMES"
done
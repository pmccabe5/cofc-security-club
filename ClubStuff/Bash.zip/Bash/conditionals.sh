#!/bin/bash

#if/if-else

NAME="Patrick"

if [ "$NAME" = "Patrick" ];
then
	echo "Welcome $NAME"
fi
echo "Enter username: "
read USERNAME
if [ "$USERNAME" = "Patrick" ];
then
	echo "Welcome $USERNAME"
else
	echo "Invalid username please register an account"
fi
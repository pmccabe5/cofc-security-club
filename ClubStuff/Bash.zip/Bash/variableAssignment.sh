#!/bin/bash
#Variable assignment
NAME="Patrick"
echo "My name is $NAME"
SPORT="Foot"
echo "The most popular sport is ${SPORT}ball"

#!/bin/bash

#positional parameters

echo "Execution of script $0"
echo "Enter the name of the user: $1"

#add user

adduser --home /$1 $1